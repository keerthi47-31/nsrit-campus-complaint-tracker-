import tempfile
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app import create_app


def make_client():
    database = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    database.close()
    app = create_app({"TESTING": True, "DATABASE": database.name, "SECRET_KEY": "test", "ADMIN_PASSWORD": "secret"})
    return app.test_client()


def sample_complaint():
    return {"student_name": "Anjali", "student_department": "CSE", "title": "Broken classroom fan", "category": "Classroom Facilities", "location": "Block A, Room 204", "description": "The fan does not turn on.", "priority": "Medium"}


def test_submit_and_list_complaint():
    client = make_client()
    response = client.post("/api/complaints", json=sample_complaint())
    assert response.status_code == 201
    complaints = client.get("/api/complaints").get_json()
    assert complaints[0]["status"] == "Open"


def test_only_admin_can_update_status():
    client = make_client()
    item = client.post("/api/complaints", json=sample_complaint()).get_json()
    assert client.patch(f"/api/complaints/{item['id']}", json={"status": "Resolved"}).status_code == 401
    assert client.post("/api/auth/login", json={"username": "admin", "password": "secret"}).status_code == 200
    assert client.patch(f"/api/complaints/{item['id']}", json={"status": "Resolved"}).get_json()["status"] == "Resolved"
