# NSRIT Campus Complaint Tracker

A full-stack hackathon project for NSRIT Engineering College. Students submit campus complaints; authorised administrators review them and update the status.

## Features

- Student complaint form with department, category, location, priority, and description
- Shared SQLite database instead of browser-only storage
- Admin login protected by a server session
- Admin status workflow: **Open → In Progress → Resolved**
- Dashboard statistics and status filter
- Automated API tests

## Project structure

```text
campus-complaint-tracker/
├── frontend/              # HTML, CSS, and browser JavaScript
├── backend/               # Flask API and server logic
│   ├── app.py
│   └── requirements.txt
├── data/                  # Local SQLite database and sample data
├── tests/                 # Automated backend tests
├── .env.example           # Example administrator settings
├── .gitignore
└── README.md
```

## Run locally on Windows

1. Install Python 3.11 or newer from [python.org](https://www.python.org/downloads/). During installation, select **Add Python to PATH**.
2. Open PowerShell in the `campus-complaint-tracker` folder.
3. Run these commands:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r backend\requirements.txt
python backend\app.py
```

4. Open this address in a browser:

```text
http://127.0.0.1:5000
```

## Demo administrator login

For local testing only:

```text
Username: admin
Password: campus123
```

Before deploying, create a `.env` file from `.env.example` and use a new password and secret key. Do not publish real passwords in GitHub.

## Run automated tests

With the virtual environment activated:

```powershell
pip install pytest
pytest
```

## Deployment note

This project has a Python backend, so GitHub Pages alone cannot host it. GitHub can store the source code; deploy the running Flask app to a Python-compatible host such as Render or Railway. For a production version, replace SQLite with a managed database and use a real authentication service.
