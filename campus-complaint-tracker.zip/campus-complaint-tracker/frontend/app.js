const $ = (selector) => document.querySelector(selector);
const studentView = $("#studentView");
const loginView = $("#loginView");
const adminView = $("#adminView");

function show(view) {
  [studentView, loginView, adminView].forEach((section) => section.classList.add("hidden"));
  view.classList.remove("hidden");
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

function statusClass(status) {
  return status === "Open" ? "open" : status === "In Progress" ? "progress" : "resolved";
}

function complaintCard(item, isAdmin = false) {
  const actions = isAdmin ? `<div class="admin-actions"><select id="status-${item.id}"><option ${item.status === "Open" ? "selected" : ""}>Open</option><option ${item.status === "In Progress" ? "selected" : ""}>In Progress</option><option ${item.status === "Resolved" ? "selected" : ""}>Resolved</option></select><button data-update="${item.id}">Update status</button></div>` : "";
  const student = isAdmin ? `<span><b>Student:</b> ${item.student_name} (${item.student_department})</span>` : "";
  return `<article class="complaint"><h3>#${item.id} — ${item.title}</h3><p>${item.description}</p><div class="details">${student}<span><b>Category:</b> ${item.category}</span><span><b>Location:</b> ${item.location}</span><span class="priority-${item.priority.toLowerCase()}"><b>Priority:</b> ${item.priority}</span><span><b>Created:</b> ${item.created_at}</span></div><p><span class="tag ${statusClass(item.status)}">${item.status}</span></p>${actions}</article>`;
}

async function loadComplaints(isAdmin = false) {
  const filter = isAdmin ? `?status=${encodeURIComponent($("#statusFilter").value)}` : "";
  const complaints = await api(`/api/complaints${filter}`);
  const list = isAdmin ? $("#adminList") : $("#studentList");
  list.innerHTML = complaints.length ? complaints.map((item) => complaintCard(item, isAdmin)).join("") : "<p>No complaints found.</p>";
  if (isAdmin) {
    const counts = ["Open", "In Progress", "Resolved"].map((status) => complaints.filter((c) => c.status === status).length);
    $("#stats").innerHTML = `<div class="stat"><b>${counts[0]}</b>Open</div><div class="stat"><b>${counts[1]}</b>In Progress</div><div class="stat"><b>${counts[2]}</b>Resolved</div>`;
    document.querySelectorAll("[data-update]").forEach((button) => button.addEventListener("click", async () => {
      try { await api(`/api/complaints/${button.dataset.update}`, { method: "PATCH", body: JSON.stringify({ status: $(`#status-${button.dataset.update}`).value }) }); await loadComplaints(true); }
      catch (error) { alert(error.message); }
    }));
  }
}

$("#complaintForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(["student_name", "student_department", "title", "category", "location", "priority", "description"].map((id) => [id, $(`#${id}`).value]));
  const message = $("#formMessage");
  try { await api("/api/complaints", { method: "POST", body: JSON.stringify(payload) }); event.target.reset(); message.textContent = "Complaint submitted successfully. Your status is Open."; message.classList.remove("error"); await loadComplaints(); }
  catch (error) { message.textContent = error.message; message.classList.add("error"); }
});

$("#adminButton").addEventListener("click", async () => {
  const me = await api("/api/auth/me");
  show(me.is_admin ? adminView : loginView);
  if (me.is_admin) loadComplaints(true);
});
$("#backButton").addEventListener("click", () => show(studentView));
$("#loginForm").addEventListener("submit", async (event) => {
  event.preventDefault(); const message = $("#loginMessage");
  try { await api("/api/auth/login", { method: "POST", body: JSON.stringify({ username: $("#username").value, password: $("#password").value }) }); event.target.reset(); show(adminView); await loadComplaints(true); }
  catch (error) { message.textContent = error.message; message.classList.add("error"); }
});
$("#logoutButton").addEventListener("click", async () => { await api("/api/auth/logout", { method: "POST" }); show(studentView); });
$("#statusFilter").addEventListener("change", () => loadComplaints(true));
loadComplaints();
